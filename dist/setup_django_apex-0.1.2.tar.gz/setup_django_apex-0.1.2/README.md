# setup_django_apex

setup_django_apex is a simple library to set up Django projects with multiple apps interactively.

## Installation

You can install the library using pip:

```bash
pip install setup_django_apex
